# Laravel-CRUD

Laravel API and Resouces and Controller CRUD


#USAGE
http://127.0.0.1:8000/api/userInfo // GET ALL with Pagination
http://127.0.0.1:8000/api/userInfo/{id} // GET SPECIFIC ex: http://127.0.0.1:8000/api/userInfo/1
http://127.0.0.1:8000/crud // For Form CRUD
