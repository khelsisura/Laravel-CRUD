<nav class="navbar navbar-expand-lg navbar-light bg-primary p-16">
    <a class="navbar-brand text-white">
    &nbsp;
        <!-- <img src="/assets/sample-logo.png" width="30" height="30" class="d-inline-block align-top" alt=""> -->
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item text-white nav-link active" href="#">Home</a>
            <a class="nav-item text-white nav-link" href="#">Aboout Us</a>
            <a class="nav-item text-white nav-link" href="#">Contact Us</a>
        </div>
    </div> -->
</nav>