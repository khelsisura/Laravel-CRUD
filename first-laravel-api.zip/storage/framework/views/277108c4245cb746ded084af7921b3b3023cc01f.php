<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="<?php echo e(URL::asset('/')); ?>" target="_blank">
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/custom.scss')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous" />
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Quicksand">
    <title><?php echo e(config('app.name', 'Crud App')); ?></title>
</head>


<body>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>

</html><?php /**PATH E:\xampp\htdocs\laravel\first-laravel-api\resources\views/layouts/app.blade.php ENDPATH**/ ?>