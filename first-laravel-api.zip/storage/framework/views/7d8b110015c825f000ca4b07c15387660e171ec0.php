<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Lorem Ipsum</h1>
    <div class="d-flex">
        <div class="p-2 align-self-center">
            <?php if(session('success')): ?>
            <div class="alert alert-success mb-0">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="p-2 ml-auto">
            <a class="btn btn-primary" href="<?php echo e(route('crud.create')); ?>" target="_self">
                <i class="fas fa-plus"></i>
                Add
            </a>
        </div>
    </div>
    <div>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Details</th>
                    <th scope="col" class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $incrementalID = 1; ?>
                <?php if(count($crud) > 0): ?>
                <?php $__currentLoopData = $crud; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($incrementalID++); ?>

                    </td>
                    <td>
                        <?php echo e($value->title); ?>

                    </td>
                    <td>
                        <?php echo e($value->body); ?>

                    </td>
                    <td class="pt-2 text-center">
                        <a class="btn btn-link text-info" target="_self" href="<?php echo e(route('crud.show', $value->id)); ?>">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a class="btn btn-link text-info" target="_self" href="<?php echo e(route('crud.edit', $value->id)); ?>">
                            <i class="fas fa-edit"></i>
                        </a>
                        <?php echo Form::open(['method' => 'DELETE', 'route' => ['crud.destroy', $value->id], 'class' => 'd-inline', 'target' => '_self']); ?>

                        <button type="submit" style="display: inline;" class="btn btn-link text-danger">
                            <i class="fas fa-trash"></i>
                        </button>
                        <?php echo Form::close(); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif(count($crud) == 0): ?>
                <tr>
                    <td>
                        <b>No Data</b>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\first-laravel-api\resources\views/crud/index.blade.php ENDPATH**/ ?>